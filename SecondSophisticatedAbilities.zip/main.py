i = float(input(" Put in Initial speed: "))

a = float(input(" Put in Acceleration: "))

t = float(input(" Put in time: "))

print("Distance is equal to " + str((i*t) + (a*t*t)/2))


