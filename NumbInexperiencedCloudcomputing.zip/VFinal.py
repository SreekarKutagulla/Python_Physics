q = float(input((" Put in V(Initial): ")))
a = float(input((" Put in Acceleration: ")))
n = float(input((" Put in time: ")))

print(" V(final) is equal to " + str(q + (a*n)))